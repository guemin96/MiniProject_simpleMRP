﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfSMSApp.Model
{
    public class StockStore : Store
    {
        public int StockQuantity { get; set; }
    }
}
